import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class TUMSİNİFLAR_2258 {
    import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

    public class Main_2258 {
        public static void main(String[] args) {
            String dosyaAdi = "C:\\Users\\Casper\\OneDrive\\Masaüstü\\Belgeler\\Yazılım Mühendisliği 2. Sınıf\\OOP\\3.Hafta\\Urun.txt";
            List<Beverages_2258> beverages2258List = new ArrayList<>();
            List<Cereals_2258> cereals2258List = new ArrayList<>();
            List<Condiments_2258> condiments2258List = new ArrayList<>();
            List<Confections_2258> confections2258List = new ArrayList<>();
            List<DairyProducts_2258> dairyProducts2258List = new ArrayList<>();
            List<Urun> allProducts = new ArrayList<>();


            try {
                BufferedReader bufferedReader = new BufferedReader(new FileReader(dosyaAdi));
                String satir;

                while ((satir = bufferedReader.readLine()) != null) {
                    String[] veri = satir.split("\t");
                    if (veri.length == 5) {
                        String ad = veri[0];
                        int kategoriIndex = Integer.parseInt(veri[1]);
                        String birimAgirligi = veri[2];
                        double birimFiyat = Double.parseDouble(veri[3]);
                        int stokMiktari = Integer.parseInt(veri[4]);
                        if(kategoriIndex==1){
                            Urun beverages= new Beverages_2258(ad, kategoriIndex, birimAgirligi, birimFiyat, stokMiktari);
                            beverages2258List.add((Beverages_2258) beverages);
                        }
                        if(kategoriIndex==2){
                            Urun condiments= new Condiments_2258(ad, kategoriIndex, birimAgirligi, birimFiyat, stokMiktari);
                            condiments2258List.add((Condiments_2258)condiments);
                        }
                        if(kategoriIndex==3){
                            Urun confections= new Confections_2258(ad, kategoriIndex, birimAgirligi, birimFiyat, stokMiktari);
                            confections2258List.add((Confections_2258) confections);
                        }
                        if(kategoriIndex==4){
                            Urun dairyProducts= new DairyProducts_2258(ad, kategoriIndex, birimAgirligi, birimFiyat, stokMiktari);
                            dairyProducts2258List.add((DairyProducts_2258) dairyProducts);
                        }
                        if(kategoriIndex==5){
                            Urun cereals= new Cereals_2258(ad, kategoriIndex, birimAgirligi, birimFiyat, stokMiktari);
                            cereals2258List.add((Cereals_2258)cereals);
                        }

                    }
                }
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            while (true) {
                System.out.println("1: StokMiktarinaGoreUrunFiyatlariGuncelle");
                System.out.println("2: UrunZamYap");
                System.out.println("3: IcecekStoklariniGuncelle");
                System.out.println("4: CesniBirimAgirlikGuncelle");
                System.out.println("5: SekerlemeDetayEkle");
                System.out.println("6: SutUrunleriniSil");
                System.out.println("7: TahilUrunEkle");
                System.out.println("8: Çıkış");

                Scanner scanner = new Scanner(System.in);
                System.out.print("Lütfen bir seçenek girin: ");
                int secim = scanner.nextInt();

                switch (secim) {
                    case 1:
                        System.out.println("Miktar giriniz:");
                        int miktar= scanner.nextInt();
                        System.out.println("Güncel fiyat giriniz:");
                        int fiyat= scanner.nextInt();
                        Urun.StokMiktarinaGoreUrunFiyatlariGuncelle(beverages2258List,miktar,fiyat);
                        for (Beverages_2258 b : beverages2258List) {
                            System.out.print( b.adi+"\t");
                            System.out.print( b.KategoriIndex+"\t");
                            System.out.print(b.BirimAgirligi+"\t");
                            System.out.print(b.BirimFiyati+"\t");
                            System.out.print(b.StokMiktari+"\t");
                            System.out.println();
                        }
                        break;
                    case 2:
                        allProducts.addAll(beverages2258List);
                        allProducts.addAll(cereals2258List);
                        allProducts.addAll(condiments2258List);
                        allProducts.addAll(confections2258List);
                        allProducts.addAll(dairyProducts2258List);
                        System.out.println("Yapılacak zam miktarını giriniz:");
                        int zam= scanner.nextInt();
                        Urun.UrunZamYap(zam,allProducts);
                        break;
                    case 3:
                        System.out.println("Miktar giriniz:");
                        int x= scanner.nextInt();
                        Beverages_2258.IcecekStoklariniGuncelle(x);
                        for (Beverages_2258 b : beverages2258List) {
                            System.out.print(b.adi + "\t");
                            System.out.print(b.KategoriIndex + "\t");
                            System.out.print(b.BirimAgirligi + "\t");
                            System.out.print(b.BirimFiyati + "\t");
                            System.out.print(b.StokMiktari + "\t");
                            System.out.println();
                        }
                        break;
                    case 4:
                        System.out.println("N degerini giriniz:");
                        int N= scanner.nextInt();
                        System.out.println("Yeni ağırlık giriniz:");
                        String agirlik= scanner.next();
                        Condiments_2258.CesniBirimAgirlikGuncelle(condiments2258List,N,agirlik);
                        for (Condiments_2258 b : condiments2258List) {
                            System.out.print( b.adi+"\t");
                            System.out.print( b.KategoriIndex+"\t");
                            System.out.print(b.BirimAgirligi+"\t");
                            System.out.print(b.BirimFiyati+"\t");
                            System.out.print(b.StokMiktari+"\t");
                            System.out.println();
                        }
                        break;
                    case 5:
                        //sekerlemeDetayEkle  fonksiyonunu yazdım ama anlamadığım bir şekilde
                        // diğer fonksiyonları çağırabiliyorken IDE bu fonksiyonu çağırmadı :'(

                        break;
                    case 6:
                        System.out.println("min degerini giriniz:");
                        int min= scanner.nextInt();
                        System.out.println("max degerini giriniz:");
                        int max= scanner.nextInt();
                        DairyProducts_2258.SutUrunleriniSil(min,max, dairyProducts2258List);
                        break;
                    case 7:
                        Cereals_2258.TahilUrunEkle("ekmek","200gr",9.0,35, cereals2258List);
                        break;
                    case 8:
                        System.out.println("Çıkış yapılıyor...");
                        System.exit(0);
                    default:
                        System.out.println("Geçersiz bir seçenek girdiniz. Lütfen tekrar deneyin.");
                }
            }
        }
    }


    import java.util.ArrayList;
import java.util.List;

    public class Urun {
        static java.util.List<Beverages_2258> beverages2258List = new ArrayList<>();
        static java.util.List<Cereals_2258> cereals2258List = new ArrayList<>();
        static java.util.List<Condiments_2258> condiments2258List = new ArrayList<>();
        static java.util.List<Confections_2258> confections2258List = new ArrayList<>();
        static List<DairyProducts_2258> dairyProducts2258List = new ArrayList<>();
        static java.util.List<Urun> allProducts = new ArrayList<>();
        String adi;
        int KategoriIndex;
        String BirimAgirligi;
        double BirimFiyati;
        int StokMiktari;

        public Urun(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
            this.adi = adi;
            this.KategoriIndex = kategoriIndex;
            this.BirimAgirligi = birimAgirligi;
            this.BirimFiyati = birimFiyati;
            this.StokMiktari = stokMiktari;
        }
        static void StokMiktarinaGoreUrunFiyatlariGuncelle (List<Beverages_2258> beverages2258List, int stokAdedi, int guncelFiyat){

            for (Beverages_2258 b : beverages2258List) {
                if (b.StokMiktari > stokAdedi) {
                    b.BirimFiyati = guncelFiyat * (1 + (stokAdedi - b.StokMiktari) / 100.0);
                }
                else{
                    b.BirimFiyati=b.BirimFiyati;
                }
            }
            for (Cereals_2258 cer : cereals2258List) {
                if (cer.StokMiktari > stokAdedi) {
                    cer.BirimFiyati = guncelFiyat * (1 + (stokAdedi - cer.StokMiktari) / 100.0);
                }
                else{
                    cer.BirimFiyati=cer.BirimFiyati;
                }
            }
            for (Condiments_2258 con : condiments2258List) {
                if (con.StokMiktari > stokAdedi) {
                    con.BirimFiyati = guncelFiyat * (1 + (stokAdedi - con.StokMiktari) / 100.0);
                }
                else{
                    con.BirimFiyati=con.BirimFiyati;
                }
            }
            for (Confections_2258 conf : confections2258List) {
                if (conf.StokMiktari > stokAdedi) {
                    conf.BirimFiyati = guncelFiyat * (1 + (stokAdedi - conf.StokMiktari) / 100.0);
                }
                else{
                    conf.BirimFiyati=conf.BirimFiyati;
                }
            }
            for (DairyProducts_2258 der : dairyProducts2258List) {
                if (der.StokMiktari > stokAdedi) {
                    der.BirimFiyati = guncelFiyat * (1 + (stokAdedi - der.StokMiktari) / 100.0);
                }
                else{
                    der.BirimFiyati=der.BirimFiyati;
                }
            }

        }
        static void UrunZamYap(int X, List<Urun> allProducts) {
            if (allProducts.isEmpty()) {
                System.out.println("Ürün bulunamadı.");
                return;
            }

            Urun enDusukFiyatliUrun = allProducts.get(0);
            double enDusukFiyat = enDusukFiyatliUrun.getBirimFiyati();

            for (Urun urun : allProducts) {
                if (urun.getBirimFiyati() < enDusukFiyat) {
                    enDusukFiyat = urun.getBirimFiyati();
                    enDusukFiyatliUrun = urun;
                }
            }

            double zamOrani = X / 100.0;
            enDusukFiyatliUrun.setBirimFiyati(enDusukFiyatliUrun.getBirimFiyati() * (1 + zamOrani));
            System.out.println("En düşük fiyatlı ürüne %" + X + " zam yapıldı.");

            for (Urun b : allProducts) {
                System.out.print(b.adi + "\t");
                System.out.print(b.KategoriIndex + "\t");
                System.out.print(b.BirimAgirligi + "\t");
                System.out.print(b.BirimFiyati + "\t");
                System.out.print(b.StokMiktari + "\t");
                System.out.println();
            }
        }


        public static List<Beverages_2258> getBeveragesList() {
            return beverages2258List;
        }

        public static void setBeveragesList(List<Beverages_2258> beverages2258List) {
            Urun.beverages2258List = beverages2258List;
        }

        public List<Cereals_2258> getCerealsList() {
            return cereals2258List;
        }

        public void setCerealsList(List<Cereals_2258> cereals2258List) {
            this.cereals2258List = cereals2258List;
        }

        public List<Condiments_2258> getCondimentsList() {
            return condiments2258List;
        }

        public void setCondimentsList(List<Condiments_2258> condiments2258List) {
            this.condiments2258List = condiments2258List;
        }

        public List<Confections_2258> getConfectionsList() {
            return confections2258List;
        }

        public void setConfectionsList(List<Confections_2258> confections2258List) {
            this.confections2258List = confections2258List;
        }

        public List<DairyProducts_2258> getDairyProductsList() {
            return dairyProducts2258List;
        }

        public void setDairyProductsList(List<DairyProducts_2258> dairyProducts2258List) {
            this.dairyProducts2258List = dairyProducts2258List;
        }

        public String getAdi() {
            return adi;
        }

        public void setAdi(String adi) {
            this.adi = adi;
        }

        public int getKategoriIndex() {
            return KategoriIndex;
        }

        public void setKategoriIndex(int kategoriIndex) {
            KategoriIndex = kategoriIndex;
        }

        public String getBirimAgirligi() {
            return BirimAgirligi;
        }

        public void setBirimAgirligi(String birimAgirligi) {
            BirimAgirligi = birimAgirligi;
        }

        public double getBirimFiyati() {
            return BirimFiyati;
        }

        public void setBirimFiyati(double birimFiyati) {
            BirimFiyati = birimFiyati;
        }

        public int getStokMiktari() {
            return StokMiktari;
        }

        public void setStokMiktari(int stokMiktari) {
            StokMiktari = stokMiktari;
        }
    }
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

    public class DairyProducts_2258 extends Urun {
        private static List<DairyProducts_2258> dairyProducts2258List = new ArrayList<>();
        public DairyProducts_2258(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
            super(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari);
        }

        static void SutUrunleriniSil(int minFiyat, int maxFiyat,List<DairyProducts_2258> dairyProducts2258List) {

            Iterator<DairyProducts_2258> iterator = dairyProducts2258List.iterator();

            while (iterator.hasNext()) {
                DairyProducts_2258 sutUrunu = iterator.next();
                if (sutUrunu.getBirimFiyati() >= minFiyat && sutUrunu.getBirimFiyati() <= maxFiyat) {
                    System.out.println("Süt ürünü silindi: " + sutUrunu.getAdi());
                    iterator.remove();
                } }
            for (Urun b : dairyProducts2258List) {
                System.out.print( b.adi+"\t");
                System.out.print( b.KategoriIndex+"\t");
                System.out.print(b.BirimAgirligi+"\t");
                System.out.print(b.BirimFiyati+"\t");
                System.out.print(b.StokMiktari+"\t");
                System.out.println();
            }

        }
    }
    public class Confections_2258 extends Urun {
        private String detay;

        public Confections_2258(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari, String detay) {
            super(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari);
            this.detay = detay;
        }
        public Confections_2258(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
            super(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari);

        }
        public void sekerlemeDetayEkle(String adi, String yeniDetay) {
            if (this.adi.equals(adi)) {
                this.detay += yeniDetay;
                System.out.println("Detay başarıyla eklendi: " + yeniDetay);
            } else {
                System.out.println("Ürün bulunamadı.");
            }
        }

        public String getDetay() {
            return detay;
        }

        public void setDetay(String detay) {
            this.detay = detay;
        }
    }

import java.util.ArrayList;
import java.util.List;

    public class Condiments_2258 extends Urun {
        private static List<Condiments_2258> condiments2258List = new ArrayList<>();
        public Condiments_2258(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
            super(adi, kategoriIndex,birimAgirligi, birimFiyati, stokMiktari);
        }
        static void CesniBirimAgirlikGuncelle(List<Condiments_2258> condiments2258List, int N, String yeniAgirlik){
            if (N >= 1 && N <= condiments2258List.size()) {
                Condiments_2258 cesni = condiments2258List.get(N - 1); // N. sıradaki çeşni nesnesini al
                cesni.BirimAgirligi = yeniAgirlik;
                System.out.println("Ağırlık güncellendi: " + cesni.BirimAgirligi);
            } else {
                System.out.println("Geçersiz indis.");
            }
        }
    }

import java.util.List;
    public class Cereals_2258 extends Urun {
        public Cereals_2258(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
            super(adi, kategoriIndex,birimAgirligi, birimFiyati, stokMiktari);
        }
        static void TahilUrunEkle(String adi, String birimAgirligi, double birimFiyati, int stokMiktari, List<Cereals_2258> cereals2258List) {
            Cereals_2258 yeniTahilUrunu = new Cereals_2258(adi, 5, birimAgirligi, birimFiyati, stokMiktari);
            cereals2258List.add(yeniTahilUrunu);
            System.out.println("Yeni tahıl ürünü eklendi: " + yeniTahilUrunu.getAdi());
            System.out.println("Güncellenmiş tahıl ürünleri listesi:");
            for (Cereals_2258 tahilUrunu : cereals2258List) {
                System.out.println( tahilUrunu.getAdi() +
                        "\t" + tahilUrunu.getKategoriIndex() +
                        "\t" + tahilUrunu.getBirimAgirligi() +
                        "\t" + tahilUrunu.getBirimFiyati() +
                        "\t" + tahilUrunu.getStokMiktari());
            }
        }
    }
import java.util.List;
    public class Cereals_2258 extends Urun {
        public Cereals_2258(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
            super(adi, kategoriIndex,birimAgirligi, birimFiyati, stokMiktari);
        }
        static void TahilUrunEkle(String adi, String birimAgirligi, double birimFiyati, int stokMiktari, List<Cereals_2258> cereals2258List) {
            Cereals_2258 yeniTahilUrunu = new Cereals_2258(adi, 5, birimAgirligi, birimFiyati, stokMiktari);
            cereals2258List.add(yeniTahilUrunu);
            System.out.println("Yeni tahıl ürünü eklendi: " + yeniTahilUrunu.getAdi());
            System.out.println("Güncellenmiş tahıl ürünleri listesi:");
            for (Cereals_2258 tahilUrunu : cereals2258List) {
                System.out.println( tahilUrunu.getAdi() +
                        "\t" + tahilUrunu.getKategoriIndex() +
                        "\t" + tahilUrunu.getBirimAgirligi() +
                        "\t" + tahilUrunu.getBirimFiyati() +
                        "\t" + tahilUrunu.getStokMiktari());
            }
        }
    }
import java.util.ArrayList;
import java.util.List;

    public class Beverages_2258 extends Urun {
        private static List<Beverages_2258> beverages2258List = new ArrayList<>();
        public Beverages_2258(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
            super(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari);
            beverages2258List.add(this);
        }
        static void IcecekStoklariniGuncelle(int miktar){
            for (Beverages_2258 b : beverages2258List) {
                b.StokMiktari= b.StokMiktari+miktar;
                if(b.StokMiktari<0){
                    b.StokMiktari= Integer.parseInt(null);
                }
                else{
                    b.StokMiktari= b.StokMiktari;
                }
            }
        }
    }

}
